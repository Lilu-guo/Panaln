/*============================================
# Filename: InArray.cpp
# Ver 1.0 2021-09-08
# Copyright (C) Zongtao He, Pengfei Liu, Hongbojiang, Hongwei Huo, and Jeffrey S. Vitter.
#
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 or later of the License.
#
# Description: 
=============================================*/
#include "InArray.h"
#include<string.h>
#include<stdlib.h>
#include<iostream>
#include<math.h>
using namespace std;
InArray::~InArray(void)
{
	delete [] data;
}
InArray::InArray()
{
	this->datanum = 0;
	this->datawidth = 0;
}
InArray::InArray(fm_int data_num, int data_width)
{
	if(data_num<=0||data_width<=0){
		cout<<data_num<<"  "<<data_width<<"InArray build error: data_num<=0||data_width<=0"<<endl;
		exit(0);
	}
	else
	{
		this->datanum =data_num;
		this->datawidth =data_width;
	    fm_int totlesize=datanum*datawidth;
		if(totlesize%32==0)
			totlesize=totlesize/32+1;
		else
			totlesize=(totlesize/32)+2;
		this->data =new u32[totlesize];//valgrand warns
		memset(data,0,4*totlesize);
		mask = (u64)pow(2,datawidth)-1;
	}
}

void InArray::SetValue (fm_int index, u64 v)
{

	if(index>datanum-1|| index<0)
	{
		cerr<<"InArray:index out of boundary:"<<datanum<<"  "<<index<<endl;
		exit(0);
	}
	else if(v>mask)
	{
		cerr<<"InArray:value:"<<v<<" is out of boundary"<<endl;
		exit(0);
	}
	else
	{
		u64 value=v;
		fm_int anchor=(index*datawidth)>>5;
		u64 temp1=data[anchor];
		u32 temp2=data[anchor+1];
		temp1=(temp1<<32)+temp2;
		i32 overloop=((anchor+2)<<5)-(index+1)*datawidth;
		if(overloop<0)
		{
			value=(value>>(-overloop));//35
			temp1=temp1+value;
			data[anchor+1]=(temp1&(0xffffffff));
			data[anchor]=(temp1>>32)&(0xffffffff);
			data[anchor+2]=(v<<(32+overloop))&(0xffffffff);
		}
		else
		{
			value=(value<<overloop);
			temp1=temp1+value;
			data[anchor+1]=(temp1&(0xffffffff));
			data[anchor]=(temp1>>32)&(0xffffffff);
		}
	}
}

fm_int InArray::GetNum ()
{
	return datanum;
}
fm_int InArray::GetMemorySize()
{
	return (datanum*datawidth)/8;
}


int InArray::GetDataWidth()
{
	return datawidth;
}

u64 InArray::GetValue(fm_int index)
{
	if(index>datanum-1||index<0)
	{
		cerr<<datanum-1<<"  "<<index<<" InArray:GetValue: index out of boundary"<<endl;
		exit(0);
	}

	fm_int anchor=(index*datawidth)>>5;
	u64 temp1=data[anchor];
	u32 temp2=data[anchor+1];
	u32 temp3=data[anchor+2];
	i32 overloop=((anchor+2)<<5)-(index+1)*datawidth;
	temp1=(temp1<<32)+temp2;
	if(overloop<0)
	{
	   temp1 = (temp1<<(-overloop))+(temp3>>(32+overloop));
		return temp1&mask;
	}
	else
	{
		return (temp1>>overloop)&mask;
	}
}
i64 InArray::write(savekit & s)
{

	s.writei64(datanum);
	s.writei32(datawidth);
	u64 len=(datanum*datawidth);
	if(len%32==0)
		len=len/32+1;
	else
		len=len/32+2;
	s.writeu64(len);
	s.writeu32array(data,len);
	return 1;
}
i64 InArray::load(loadkit & s)
{
	if(s.loadi64(datanum)!=1){
		cout<<"InArray datanum read error"<<endl;
		exit(0);
	}
	if(s.loadi32(datawidth)!=1){
		cout<<"InArray datawidth read error"<<endl;
		exit(0);		
	}
	u64 len=0;
	if(s.loadu64(len)!=1){
		cout<<"InArray len read error"<<endl;
		exit(0);
	}
	data=new u32[len];
	i32 f=s.loadu32array(data,len);
	if(f!=len){
		cout<<len<<" "<<f<<"InArray data read error"<<endl;
		exit(0);
	}
	
	mask=(u64)pow(2,datawidth)-1;
	return 1;
}



